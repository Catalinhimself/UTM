from collections import defaultdict
import math
import numpy as np


class GRAPH:
    def __init__(self):
        self.adj = defaultdict(list)
        self.drumMinim = int()
        self.drumMaxim = int()
        self.minListe = []
        self.maxListe = []

    def add_edge(self, initial, terminal, ponderea):
        self.adj[initial].append((terminal, ponderea))

    def read_adj(self):
        self.adj = defaultdict(list)
        print("citirea listei de adiacenta")
        i = 1
        while True:
            print("pentru a termina tastati ( q )")
            print("aveti muchia", i, "cu extremitatea initiala")
            initial = input()
            if initial == "q":
                break
            print("si extremitatea terminala")
            terminal = input()
            if terminal == "q":
                break
            print("ponderea este")
            ponderea = input()
            if ponderea == "q":
                break
            self.add_edge(int(initial), int(terminal), int(ponderea))
            i += 1
        self.clean()

    def clean(self):
        for v in [*self.adj]:
            self.adj[v].sort()
            self.adj[v] = list(dict(self.adj[v]).items())
            self.adj[v] = [(varf, pond)
                           for (varf, pond) in self.adj[v] if varf != v]
            for c in self.adj[v]:
                if c[0] not in [*self.adj]:
                    self.adj[c[0]] = []
        self.adj = dict(sorted(self.adj.items()))

    def print_list(self):
        print("lista de adiacenta")
        for k in [*self.adj]:
            print(k, "-", end=" ")
            for v in self.adj[k]:
                print(str(v[0])+"("+str(v[1])+")", end=", ")
            print("0")

    def ford_min(self):
        H = defaultdict(int)
        for k in [*self.adj]:
            H[k] = math.inf
        for k in [*self.adj]:
            H[k] = 0
            break
        for k in [*self.adj]:
            for v in self.adj[k]:
                if H[v[0]]-H[k] > v[1]:
                    H[v[0]] = H[k]+v[1]
        self.drumMinim = int(H[list(H).pop()])
        self.ford_aux(H)

    def ford_max(self):
        H = defaultdict(int)
        for k in [*self.adj]:
            H[k] = -math.inf
        for k in [*self.adj]:
            H[k] = 0
            break
        for k in [*self.adj]:
            for v in self.adj[k]:
                if H[v[0]]-H[k] < v[1]:
                    H[v[0]] = H[k]+v[1]
        self.drumMaxim = int(H[list(H).pop()])
        self.ford_aux(H)

    def ford_aux(self, etichete):
        grafInversat = defaultdict(list)
        for k in [*self.adj]:
            for v in self.adj[k]:
                grafInversat[v[0]].append((k, v[1]))
        # print(grafInversat)
        start = list(self.adj).pop(0)
        finish = list(self.adj).pop()
        drumuri = [[finish]]
        temp = []
        drumuriValide = []
        while drumuri:
            for drum in drumuri:
                if drum[0] == finish and drum[len(drum)-1] == start:
                    drumF = []
                    for f in drum:
                        drumF.insert(0, f)
                    drumuriValide.append(drumF)
                for v in grafInversat[drum[len(drum)-1]]:
                    if etichete[list(etichete).pop()] == self.drumMinim:
                        if etichete[drum[len(drum)-1]] - v[1] == etichete[v[0]]:
                            temp.append(drum+[v[0]])
                    else:
                        # print(  etichete[drum[len(drum)-1]] ,etichete[v[0]] ,v)
                        if etichete[drum[len(drum)-1]] - etichete[v[0]] == v[1]:
                            temp.append(drum+[v[0]])
                            # print(v)
            if not temp:
                break
            drumuri = temp
            temp = []

        if etichete[list(etichete).pop()] == self.drumMinim:
            self.minListe = drumuriValide
            self.print_paths("minim")
        if etichete[list(etichete).pop()] == self.drumMaxim:
            self.maxListe = drumuriValide
            self.print_paths("maxim")

    def bellman_kalaba_min(self):
        n = list(self.adj).pop()+1
        bk = np.zeros([n, n])
        for i in range(0, n):
            for j in range(0, n):
                bk[i][j] = -1
        varfuri = sorted(list(self.adj))
        for i in varfuri:
            for j in varfuri:
                bk[i][j] = math.inf
                if i == j:
                    bk[i][j] = 0
        for k in [*self.adj]:
            for v in self.adj[k]:
                bk[k][v[0]] = v[1]
        m = n+1
        bk.resize([m, n])
        for i in range(0, n):
            bk[m-1][i] = bk[i][n-1]

        while not (bk[m-2] == bk[m-1]).all():
            m += 1
            bk.resize([m, n])
            for i in varfuri:
                temp = math.inf
                for j in varfuri:
                    if i != j:
                        if bk[m-2][j]+bk[i][j] < temp:
                            temp = bk[m-2][j]+bk[i][j]
                            bk[m-1][i] = temp

        self.drumMinim = int(bk[m-1][list(varfuri).pop(0)])
        self.bellman_kalaba_aux(bk[m-1])

    def bellman_kalaba_max(self):
        n = list(self.adj).pop()+1
        bk = np.zeros([n, n])
        for i in range(0, n):
            for j in range(0, n):
                bk[i][j] = -1
        varfuri = sorted(list(self.adj))
        for i in varfuri:
            for j in varfuri:
                bk[i][j] = -math.inf
                if i == j:
                    bk[i][j] = 0
        for k in [*self.adj]:
            for v in self.adj[k]:
                bk[k][v[0]] = v[1]
        m = n+1
        bk.resize([m, n])
        for i in range(0, n):
            bk[m-1][i] = bk[i][n-1]

        while not (bk[m-2] == bk[m-1]).all():
            m += 1
            bk.resize([m, n])
            for i in varfuri:
                temp = -math.inf
                for j in varfuri:
                    if i != j:
                        if bk[m-2][j]+bk[i][j] > temp:
                            temp = bk[m-2][j]+bk[i][j]
                            bk[m-1][i] = temp
        self.drumMaxim = int(bk[m-1][list(varfuri).pop(0)])
        self.bellman_kalaba_aux(bk[m-1])

    def bellman_kalaba_aux(self, rand):
        start = list(self.adj).pop(0)
        finish = list(self.adj).pop()
        drumuri = [[start]]
        temp = []
        drumuriValide = []
        while drumuri:
            for drum in drumuri:
                if drum[0] == start and drum[len(drum)-1] == finish:
                    drumuriValide.append(drum)
                for v in self.adj[drum[len(drum)-1]]:
                    if rand[drum[len(drum)-1]] == rand[v[0]]+v[1]:
                        temp.append(drum+[v[0]])
            if not temp:
                break
            drumuri = temp
            temp = []
        if rand[start] == self.drumMinim:
            self.minListe = drumuriValide
            self.print_paths("minim")
        if rand[start] == self.drumMaxim:
            self.maxListe = drumuriValide
            self.print_paths("maxim")

    def print_paths(self, drum):
        print("D", drum, "= ", (self.drumMinim,
                                self.drumMaxim)[drum == "maxim"])
        for l in (self.minListe, self.maxListe)[drum == "maxim"]:
            pref = list(self.adj).pop(0)
            weight = []
            for v in l:
                if v != pref:
                    print(pref, end="")
                    weight = [item for item in self.adj[pref] if v == item[0]]
                    print(" =("+str(weight.pop()[1]) + ")=>", end=" ")
                pref = v
            print(pref)

    def removeVertex(self):
        print(self.adj)
        print("varful pe care doriti sa il stergeti :")
        v = int(input())
        for i in [*self.adj]:
            self.adj[i] = [item for item in self.adj[i] if item[0] != v]
        self.adj.pop(v, None)

    def removeEdge(self):
        print(self.adj)
        print("varful din care iese muchia :")
        e = int(input())
        print("varful in care intra muchia :")
        i = int(input())
        self.adj[e] = [item for item in self.adj[e] if item[0] != i]

    def addEdge(self):
        print(self.adj)
        print("puteti adauga orice muchie (chiar cu varfuri noi)")
        print("varful din care iese muchia :")
        e = int(input())
        print("varful in care intra muchia :")
        i = int(input())
        print("ponderea :")
        p = int(input())
        self.add_edge(e, i, p)

    def edit(self):
        print("puteti :\nsterge un varf - v\nsterge o muchie - m\nadauga o muchie - a")
        o = input()
        if o == "v":
            self.removeVertex()
        elif o == "m":
            self.removeEdge()
        elif o == "a":
            self.addEdge()
        self.clean()

    def RUN(self):
        print("program la msp")
        while True:
            print("( 0 ) - pentru a iesi")
            print("( 1 ) - introducerea listei de adiacenta: ")
            print("( 2 ) - afisarea listei de adiacenta")
            print("( 3 ) - Ford drum minim")
            print("( 4 ) - Bellman-Kalaba drum minim")
            print("( 5 ) - Ford drum maxim")
            print("( 6 ) - Bellman-Kalaba drum maxim")
            print("( 7 ) - editare")
            print("( 11 ) - grafulul conform variantei\n")
            o = input()
            if o == "0":
                break
            elif o == "1":
                self.read_adj()
            elif o == "2":
                self.print_list()
            elif o == "3":
                self.ford_min()
            elif o == "4":
                self.bellman_kalaba_min()
            elif o == "5":
                self.ford_max()
            elif o == "6":
                self.bellman_kalaba_max()
            elif o == "7":
                self.edit()
            elif o == "11":
                self.adj = defaultdict(list)
                # exemplu care a fost rezolvat la seminar
                self.add_edge(1, 2, 2)
                self.add_edge(1, 3, 4)
                self.add_edge(1, 4, 3)
                self.add_edge(2, 5, 1)
                self.add_edge(3, 4, 4)
                self.add_edge(3, 5, 5)
                self.add_edge(4, 2, 4)
                self.add_edge(4, 5, 2)

                self.clean()
                self.print_list()


graf = GRAPH()
graf.RUN()
