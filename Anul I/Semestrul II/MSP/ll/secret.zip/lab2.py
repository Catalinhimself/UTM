from collections import defaultdict


class GRAPH:
    def __init__(self):
        self.adj = defaultdict(list)

    def add_edge(self, init, term):
        self.adj[init].append(term)

    def read_adj(self):
        print("citirea listei de adiacenta")
        self.adj = defaultdict(list)
        i = 1
        while True:
            print("pentru a termina tastati ( q )")
            print("aveti muchia", i, "cu prima extremitate")
            extr1 = input()
            if extr1 == "q":
                break
            print("si a doua extremitate")
            extr2 = input()
            if extr2 == "q":
                break
            self.add_edge(int(extr1), int(extr2))
            self.add_edge(int(extr2), int(extr1))
            i += 1
        self.clean()

    def clean(self):
        self.adj = dict(sorted(self.adj.items()))
        for v in [*self.adj]:
            self.adj[v].sort()
            self.adj[v] = list(dict.fromkeys(self.adj[v]))

    def print_list(self):
        print("lista de adiacenta")
        for k in [*self.adj]:
            print(k, "-", end=" ")
            for v in self.adj[k]:
                print(v, ",", end="")
            print("0")

    def bfs(self, start):
        for k in [*self.adj]:
            for v in self.adj[k]:
                if not v in self.adj:
                    self.adj[v] = []
        visited = {}
        for k in [*self.adj]:
            visited[k] = False
        queue = []
        parcurgerea = []
        queue.append(start)
        visited[start] = True
        while queue:
            aici = queue.pop(0)
            parcurgerea.append(aici)
            for varf in self.adj[aici]:
                if not visited[varf]:
                    queue.append(varf)
                    visited[varf] = True
        cond = False
        for hz in [*visited]:
            if not visited[hz]:
                cond = True
        if cond:
            print("incepand cu varful", start,
                  "adjul nu poate fi parcurs in latime")
            print(visited)
        else:
            print("parcurgerea in latime incepand din", start)
            for v in parcurgerea:
                print(v, end=" ")
            print()

    def dfs(self, start):
        for k in [*self.adj]:
            for v in self.adj[k]:
                if not v in self.adj:
                    self.adj[v] = []
        visited = {}
        for k in [*self.adj]:
            visited[k] = False
        stack = []
        parcurgerea = []
        parcurgerea.append(start)
        stack.append(start)
        visited[start] = True
        while stack:
            aici = stack[len(stack)-1]
            if not visited[aici]:
                parcurgerea.append(aici)
                visited[aici] = True
            gata = 0
            for varf in self.adj[aici]:
                if not visited[varf]:
                    stack.append(varf)
                    break
                else:
                    gata += 1
            if not self.adj[aici]:
                stack.pop()
            elif gata == len(self.adj[aici]):
                stack.pop()
        cond = False
        for hz in [*visited]:
            if not visited[hz]:
                cond = True
        if cond:
            print("incepand cu varful", start,
                  "adjul nu poate fi parcurs in adancime")
            print(visited)
        else:
            print("parcurgerea in adancime incepand din", start)
            for v in parcurgerea:
                print(v, end=" ")
            print()

    def RUN(self):
        while True:
            print("( 0 ) - iesireai")
            print("( 1 ) - introducerea listei de adiacenta: ")
            print("( 2 ) - afisarea listei de adiacenta")
            print("( 3 ) - parcurgerea in latime")
            print("( 4 ) - parcurgerea in adancime")
            print("( 123 ) - grafulul conform variantei\n")
            o = input()
            if o == "0":
                break
            elif o == "1":
                self.read_adj()
            elif o == "2":
                self.print_list()
            elif o == "3":
                print(self.adj)
                print("parcurgerea in latime din varful- ")
                v = input()
                self.bfs(int(v))
            elif o == "4":
                print(self.adj)
                print("parcurgerea in adancime din varful- ")
                v = input()
                self.dfs(int(v))
            elif o == "123":
                self.add_edge(1, 2)
                self.add_edge(1, 3)
                self.add_edge(2, 4)
                self.add_edge(2, 5)
                self.add_edge(3, 6)
                self.print_list()
                self.bfs(1)
                self.dfs(1)


adj = GRAPH()
adj.RUN()
