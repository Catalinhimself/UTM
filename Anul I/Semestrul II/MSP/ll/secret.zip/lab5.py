from collections import defaultdict


class GRAPH:
    def __init__(self):
        self.adj = defaultdict(list)
        self.c = defaultdict(int)
        self.f = defaultdict(list)
        self.sursa = 0
        self.destinatia = 0
        self.fMax = 0
        self.L = []
        self.E = []
        self.A = []
        self.X = []
        self.XA = []
        self.WA = []

    def add_edge(self, init, term, cap):
        self.adj[int(init)].append(int(term))
        self.c[(int(init), int(term))] = int(cap)

    def read_adj(self):
        print("citirea listei de adiacenta")
        self.adj = defaultdict(list)
        self.c = defaultdict(int)
        i = 1
        while True:
            print("pentru a termina tastati ( q )")
            print("aveti muchia", i, "cu prima extremitate")
            extr1 = input()
            if extr1 == "q":
                break
            print("si a doua extremitate")
            extr2 = input()
            if extr2 == "q":
                break
            print("capacitatea arcului", extr1, "->", extr2, "este:")
            cap = input()
            self.add_edge(extr1, extr2, cap)
            i += 1
        self.clean()

    def clean(self):
        self.f = defaultdict(list)
        self.sursa = 0
        self.destinatia = 0
        self.fMax = 0
        self.L = []
        self.E = []
        self.A = []
        self.X = []
        self.XA = []
        self.WA = []
        for v in [*self.adj]:
            for c in self.adj[v]:
                if c not in [*self.adj]:
                    self.adj[c] = []
            self.adj[v].sort()
            self.adj[v] = list(dict.fromkeys(self.adj[v]))
        self.adj = dict(sorted(self.adj.items()))

    def print_list(self):
        print("lista de adiacenta")
        for k in [*self.adj]:
            print(k, "-", end=" ")
            for v in self.adj[k]:
                print(str(v)+"(" + str(self.c[(k, v)]) + "), ", end="")
            print("0")

    def removeVertex(self):
        print(self.adj)
        print("varful pe care doriti sa il stergeti :")
        v = int(input())
        for i in [*self.adj]:
            self.adj[i] = [item for item in self.adj[i] if item != v]
        self.adj.pop(v, None)

    def removeEdge(self):
        print(self.adj)
        print("varful din care iese muchia :")
        e = int(input())
        print("varful in care intra muchia :")
        i = int(input())
        self.adj[e] = [item for item in self.adj[e] if item != i]

    def addEdge(self):
        print(self.adj)
        print("puteti adauga orice muchie (chiar cu varfuri noi)")
        print("varful din care iese muchia :")
        e = int(input())
        print("varful in care intra muchia :")
        i = int(input())
        self.adj[e] = i
        print("capacitatea:")
        self.c[(e, i)] = int(input())

    def edit(self):
        print("puteti :\nsterge un varf - v\nsterge o muchie - m\nadauga o muchie - a")
        o = input()
        if o == "v":
            self.removeVertex()
        elif o == "m":
            self.removeEdge()
        elif o == "a":
            self.addEdge()
        self.clean()

    def determinare_a_b(self):
        intrari = defaultdict(bool)
        for k in [*self.adj]:
            intrari[k] = False
        for k in [*self.adj]:
            if not len(self.adj[k]):
                self.destinatia = k
            for v in self.adj[k]:
                intrari[v] = True
        for v in [*intrari]:
            if not intrari[v]:
                self.sursa = v

    def Ford_Fulkerson(self):

        F_max = 0
        s = self.sursa
        t = self.destinatia
        m = defaultdict(list)
        rg = defaultdict(list)
        c = self.c
        g = self.adj

        f = self.f
        for k in [*c]:
            f[k].append(0)

        z = 1
        A = []
        while True:
            l = [s]
            blacklist = set()
            while l[len(l)-1] != t:
                remove = True
                for v in g[l[len(l)-1]]:
                    if v not in l and v not in blacklist:
                        if sum(f[(l[len(l)-1], v)]) != c[(l[len(l)-1], v)]:
                            m[v].append(("+", l[len(l)-1]))
                            rg[v].append(l[len(l)-1])
                            l.append(v)
                            remove = False
                            break
                for v in rg[l[len(l)-1]]:
                    if v not in l and v not in blacklist:
                        if sum(f[v, (l[len(l)-1])]):
                            m[v].append(("-", l[len(l)-1]))
                            l.append(v)
                            remove = False
                            break
                if remove:
                    blacklist.add(l[len(l)-1])
                    if m[l[len(l)-1]]:
                        m[l[len(l)-1]].pop()
                    l.pop()
                    if s in blacklist:
                        A = blacklist
                        break
            if A:
                break
            self.L.append(l)
            E = []
            for i in range(1, len(l)):
                e = list(m[l[i]]).pop()
                if e[0] == "+":
                    E.append(c[(e[1], l[i])]-sum(f[(e[1], l[i])]))
                else:
                    E.append(sum(f[(l[i], e[1])]))
            self.E.append(E)
            E = min(E)
            F_max += E
            for i in l:
                if i == s:
                    p = s
                else:
                    if list(m[i]).pop()[0] == "+":
                        f[(p, i)].append(E)
                    else:
                        f[(i, p)].append(-E)
                    p = i
            z += 1

        X = list(g)
        XA = [i for i in X if i not in A]
        for o in A:
            for d in XA:
                if (o, d) in [*c]:
                    self.WA.append((o, d))
        self.A = A
        self.X = X
        self.XA = XA
        self.fMax = F_max

    def RUN(self):
        while True:
            print("( 0 ) - pentru a iesi")
            print("( 1 ) - pentru a citi de la tastatura lista de adiacenta")
            print("( 2 ) - pentru a afisa lista")
            print("( 3 ) - FORD-FULKERSON")
            print("( 4 ) - EDITARE")
            print("( 11 ) - graful pentru varianta 14")
            o = input()
            if o == "0":
                break
            elif o == "1":
                self.read_adj()
                self.determinare_a_b()
            elif o == "2":
                self.print_list()
            elif o == "3":
                self.Ford_Fulkerson()
                print("F_max = ", self.fMax)
            elif o == "4":
                self.edit()
            elif o == "11":
                self.adj = defaultdict(list)
                self.c = defaultdict(int)
                self.add_edge(1, 2, 4)
                self.add_edge(1, 3, 4)
                self.add_edge(1, 9, 3)
                self.add_edge(9, 2, 1)
                self.add_edge(9, 3, 1)
                self.add_edge(9, 10, 4)
                self.add_edge(9, 4, 2)
                self.add_edge(2, 4, 3)
                self.add_edge(3, 5, 2)
                self.add_edge(4, 6, 2)
                self.add_edge(5, 7, 1)
                self.add_edge(5, 10, 2)
                self.add_edge(6, 8, 1)
                self.add_edge(6, 10, 2)
                self.add_edge(7, 8, 3)
                self.add_edge(10, 7, 2)
                self.add_edge(10, 8, 3)
                self.clean()
                self.determinare_a_b()


graf = GRAPH()
graf.RUN()
